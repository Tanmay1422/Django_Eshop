from django.contrib import admin
from django.urls import path
from . import views
from .views import Login, Index, Cart, OrderView
from .middlewares.auth import auth_middleware

urlpatterns = [
    path('', Index.as_view(), name="indexpage"),
    path('signup/', views.signup, name='signuppage'),
    path('login/', Login.as_view(), name='loginpage'),
    path('logout/', views.logout, name='logoutpage'),
    path('cart/', Cart.as_view(), name='cartpage'),
    path('checkout/', views.checkout, name='checkoutpage'),
    path('orders/', auth_middleware(OrderView.as_view()), name='orderpage'),
]
