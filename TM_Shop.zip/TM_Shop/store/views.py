from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password, check_password
from .models.product import Product
from .models.category import Category
from .models.customer import Customer
from django.views import View
from .models.orders import Order
from django.utils.decorators import method_decorator
from store.middlewares.auth import auth_middleware

# Create your views here.
class Index(View):
    def post(self, request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove :
                    if quantity <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else :    
                    cart[product] = quantity + 1    
            else :
                cart[product] = 1            
        else:
            cart = {}
            cart[product] = 1
        request.session['cart'] = cart
        # print(request.session['cart'])
        return redirect('indexpage')
 
    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session.cart = {}
        products = None
        categories = Category.get_all_category()
        categoryID = request.GET.get('category')
        if categoryID :
            products = Product.get_all_product_by_category_id(categoryID)
        else :
            products = Product.get_all_products()
        data = {}
        data['products'] = products
        data['categories'] = categories
        # print('you are' ,request.session.get('email'))
        return render(request, 'index.html', data)
    
def signup(request):
    if request.method == 'GET':
        return render(request, 'signup.html')
    else :
        postdata = request.POST
        first_name = postdata.get('firstname')
        last_name = postdata.get('lastname')
        phone = postdata.get('phone')
        email = postdata.get('email')
        password = postdata.get('password')
        reenter_password = postdata.get('repassword')

        # Validation
        value = {
            'first_name' : first_name,
            'last_name' : last_name,
            'phone' : phone,
            'email' : email
        }

        error_message = None 

        customer = Customer(first_name = first_name,
                                last_name = last_name,
                                phone = phone,
                                email = email,
                                password = password,
                                reenter_password = reenter_password)
        
        if not first_name :
            error_message = 'First Name Required !!'
        elif not last_name :
            error_message = 'Last Name Required !!'
        elif not phone :
            error_message = 'Phone number Required !!'
        elif len(phone) < 10 :
            error_message = 'Phone number must be Ten digit !!'
        elif not email :
            error_message = 'Email Required !!'
        elif not password :
            error_message = 'Password Required !!'
        elif len(password) < 5 :
            error_message = 'Password must be more than five character !!'
        elif not reenter_password :
            error_message = 'Re-Enter Password Required'
        elif password != reenter_password :
            error_message = 'Password Not Match'
        elif customer.isExist() :
            error_message = 'Email Address Already Registered...'
        # Saving Data
        if not error_message : 
            customer.password = make_password(customer.password)       
            customer.register()
            return redirect('indexpage')
        else :
            data = {
                'error' : error_message,
                'value' : value 
            }
            return render(request, 'signup.html', data)
        
class Login(View):
    def get(self, request):
        return render(request, 'login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)
        error_message = None
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer_id'] = customer.id
                request.session['email'] = customer.email
                return redirect('indexpage')
            else :
                error_message = 'Email or Password Invalid !!'    
        else :
            error_message = 'Email or Password Invalid !!'
        data = {'error':error_message,
                'email':email}
        return render(request, 'login.html', data)
    
def logout(request):
    request.session.clear()
    return redirect('loginpage')

class Cart(View):
    def get(self, request):
        ids = request.session.get('cart').keys()
        products = Product.get_products_by_id(ids)
        return render(request, 'cart.html', {'products':products})
    
def checkout(request):
    if request.method == 'GET':
        return render(request, 'checkout.html')
    else :
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer_id')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        for product in products:
        
            order = Order(product = product,
                          customer = Customer(id = customer),
                          quantity = cart.get(str(product.id)),
                          price = product.price,
                          address = address,
                          phone = phone,
                          )
            order.placeOrder()
        request.session['cart'] = {}
        print(address ,phone, customer, cart, products)
        return redirect('cartpage')
    
class OrderView(View):
    # @method_decorator(auth_middleware)  another way to use middlewares
    def get(self, request):
        customer = request.session.get('customer_id')
        orders = Order.get_order_by_customer(customer)
        return render(request, 'orders.html', {'orders':orders})